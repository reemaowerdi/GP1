package com.example.read_me_a_story

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
