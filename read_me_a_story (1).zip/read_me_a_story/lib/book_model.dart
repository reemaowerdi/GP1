import 'dart:convert';

class Book {
  final String title;
  final String author;
  final String moral;
  final String imageStr;
  final double rating;
  final String content;
  Book({
    required this.title,
    required this.author,
    required this.moral,
    required this.imageStr,
    required this.rating,
    required this.content,
  });

  Book copyWith({
    String? title,
    String? author,
    String? moral,
    String? imageStr,
    double? rating,
    String? content,
  }) {
    return Book(
      title: title ?? this.title,
      author: author ?? this.author,
      moral: moral ?? this.moral,
      imageStr: imageStr ?? this.imageStr,
      rating: rating ?? this.rating,
      content: content ?? this.content,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'author': author,
      'moral': moral,
      'imageStr': imageStr,
      'rating': rating,
      'content': content,
    };
  }

  factory Book.fromMap(Map<String, dynamic> map) {
    return Book(
      title: map['title'] ?? '',
      author: map['author'] ?? '',
      moral: map['moral'] ?? '',
      imageStr: map['imageStr'] ?? '',
      rating: map['rating']?.toDouble() ?? 0.0,
      content: map['content'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory Book.fromJson(String source) => Book.fromMap(json.decode(source));

  @override
  String toString() {
    return 'Book(title: $title, author: $author, moral: $moral, imageStr: $imageStr, rating: $rating, content: $content)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is Book &&
        other.title == title &&
        other.author == author &&
        other.moral == moral &&
        other.imageStr == imageStr &&
        other.rating == rating &&
        other.content == content;
  }

  @override
  int get hashCode {
    return title.hashCode ^
        author.hashCode ^
        moral.hashCode ^
        imageStr.hashCode ^
        rating.hashCode ^
        content.hashCode;
  }
}
